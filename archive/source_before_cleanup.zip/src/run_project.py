# Step 1: Run or Resume the Entire Fixed-Label-Budget Project

from pipeline import main

if __name__ == '__main__':
    main()
