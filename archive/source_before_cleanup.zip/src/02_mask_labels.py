# Step 1: Inspect an Exact-Count Mask Without Writing a Mask CSV

import argparse
from masking import generate_mask


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--labels', type=int, default=200)
    parser.add_argument('--mechanism', choices=['MCAR', 'MAR', 'MNAR'], default='MCAR')
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    mask = generate_mask(args.labels, args.seed, args.mechanism)
    print(f'{args.mechanism}: {mask.is_labeled.sum()} visible labels, {(~mask.is_labeled).sum()} unlabeled rows | seed={args.seed}')


if __name__ == '__main__':
    main()
