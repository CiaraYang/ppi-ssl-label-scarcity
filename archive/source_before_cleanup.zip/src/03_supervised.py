# Step 1: Compute Only the Fully Labeled Supervised Reference

import json
from experiment import fully_labeled_reference
from pipeline import prepare_split
from storage import connect, dumps, initialize


def main():
    prepare_split()
    with connect() as db:
        initialize(db)
        found = db.execute('SELECT value FROM reference').fetchone()
        result = json.loads(found[0]) if found else fully_labeled_reference()
        db.execute('INSERT OR REPLACE INTO reference VALUES(1,?)', (dumps(result),))
        db.commit()
    for name, values in result.items():
        print(f"Fully labeled {name}: n={values['labeled_count']}, Accuracy={values['accuracy']:.4f}, Macro F1={values['macro_f1']:.4f}")


if __name__ == '__main__':
    main()
