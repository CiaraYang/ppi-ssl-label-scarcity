# Step 1: Run the Same Study as run_project.py

from pipeline import main

if __name__ == '__main__':
    main()
