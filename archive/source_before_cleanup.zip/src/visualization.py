# Step 1: Read the Matched Architecture Results from One Database

import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import DEFAULT
from experiment import METHODS
from model_utils import RESULTS_DIR
from storage import connect, get_metadata, read_results


def make_outputs():
    with connect() as db:
        status = get_metadata(db, 'status')
        if status not in ['complete', 'complete_with_failures']:
            raise ValueError('Finish or resume the study before plotting.')
        grid = get_metadata(db, 'grid')
        references = json.loads(db.execute('SELECT value FROM reference').fetchone()[0])
        rows = read_results(db)
        cases = pd.read_sql_query('SELECT * FROM cases', db)
    def requested(table):
        return table.loc[table.budget.isin(grid['budgets']) & table.mechanism.isin(grid['mechanisms']) & table.seed.isin(grid['seeds'])]
    rows, cases = requested(rows), requested(cases)
    rows[['student', 'training_method']] = rows.method.str.split(' / ', expand=True)
    audits = [json.loads(value) for value in cases.loc[cases.status == 'complete', 'audit']]
    lines = ['# Matched Student classification study', '',
             f"Status: **{status}**. Budgets: {sorted(grid['budgets'])}; seeds: {grid['seeds']}.", '',
             'Each figure fixes the Student architecture, feature processing, regularization and model capacity across Supervised, SSL soft and PPI selected. A black dashed line uses all training labels with that same architecture. CatBoost is the common cross-fitted Teacher, not a competing Student curve.', '',
             'MAR uses the same known-design IPW for all three methods. MNAR is an unadjusted stress test; oracle propensities never reach learners. CV uses visible training labels only; the shared validation/development set is for reporting. Test performance is not evaluated. Shaded bands are between-mask SD, not confidence intervals.', '']

    # Step 2: Draw Only Three Methods and One Matched Full-Label Reference per Figure
    colors = ['#2563eb', '#d97706', '#15803d']
    for student in DEFAULT.student_models:
        subset = rows.loc[rows.student == student]
        grouped = subset.groupby(['mechanism', 'budget', 'training_method'])
        means = grouped[['accuracy', 'macro_f1']].mean()
        stds = grouped[['accuracy', 'macro_f1']].std().fillna(0.)
        reference = references[student]
        mechanisms, budgets = grid['mechanisms'], sorted(grid['budgets'])
        fig, axes = plt.subplots(2, len(mechanisms), figsize=(5.3*len(mechanisms), 8), squeeze=False, layout='constrained')
        for row, metric in enumerate(['accuracy', 'macro_f1']):
            lower = min(float((means[metric]-stds[metric]).min()), reference[metric])
            upper = max(float((means[metric]+stds[metric]).max()), reference[metric])
            limits = (max(0, lower-.04), min(1, upper+.04))
            for column, mechanism in enumerate(mechanisms):
                ax = axes[row, column]
                for method, color in zip(METHODS, colors):
                    keys = [(mechanism, budget, method) for budget in budgets]
                    ys = np.array([means.loc[key, metric] if key in means.index else np.nan for key in keys])
                    sd = np.array([stds.loc[key, metric] if key in stds.index else np.nan for key in keys])
                    ax.plot(budgets, ys, marker='o', linewidth=2, markersize=5, color=color, label=method)
                    ax.fill_between(budgets, ys-sd, ys+sd, color=color, alpha=.10, linewidth=0)
                ax.axhline(reference[metric], color='black', linestyle='--', linewidth=1.8,
                           label=f"Fully labeled {student} (n={reference['labeled_count']:,})")
                ax.set_xscale('log')
                ax.set_xticks(budgets, [str(x) for x in budgets])
                ax.minorticks_off()
                if len(budgets) == 1:
                    ax.set_xlim(budgets[0]*.8, budgets[0]*1.2)
                ax.set(title=mechanism, xlabel='Visible training labels', ylim=limits)
                if column == 0:
                    ax.set_ylabel('Validation Accuracy' if metric == 'accuracy' else 'Validation Macro F1')
                ax.grid(alpha=.18)
        handles, labels = axes[0, 0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='outside lower center', ncol=4, fontsize=10)
        fig.suptitle(f'{student} Student | CatBoost Teacher | mean ± SD across {len(grid["seeds"])} masks\nSame Student within each comparison; all MAR methods use IPW', fontsize=13)
        filename = f'learning_curves_{student.lower()}.png'
        fig.savefig(RESULTS_DIR/filename, dpi=180)
        plt.close(fig)
        lines += [f'## {student} Student', '', f'![{student} learning curves]({filename})', '',
                  f"Fully labeled reference: Accuracy **{reference['accuracy']:.4f}**, Macro F1 **{reference['macro_f1']:.4f}**.", '',
                  '| Mechanism | Labels | Supervised F1 | SSL soft F1 | PPI selected F1 | PPI − Supervised | λ=0 / seeds |',
                  '|---|---:|---:|---:|---:|---:|---:|']
        for mechanism in mechanisms:
            for budget in budgets:
                values = [means.loc[(mechanism, budget, method), 'macro_f1'] if (mechanism, budget, method) in means.index else np.nan for method in METHODS]
                selected = subset.loc[(subset.mechanism == mechanism) & (subset.budget == budget) & (subset.training_method == 'PPI selected')]
                zero = int((selected.lambda_value == 0).sum())
                delta = selected.delta_f1.mean()
                lines.append(f'| {mechanism} | {budget} | {values[0]:.4f} | {values[1]:.4f} | {values[2]:.4f} | {delta:+.4f} | {zero} / {len(selected)} |')
        entries = [a['students'][student] for a in audits]
        no_cv = sum(a['cv_folds'] == 0 for a in entries)
        zero = sum(a['ppi_selected_lambda'] == 0 for a in entries)
        nonzero = [a['ppi_probability_mean_absolute_change'] for a in entries if a['ppi_selected_lambda'] > 0]
        lines += ['', f'PPI selection: λ=0 in **{zero}/{len(entries)}** cases; no-CV small-class fallback in **{no_cv}** cases. Mean absolute probability change for nonzero λ: **{np.mean(nonzero) if nonzero else 0:.6f}**.', '']

    # Step 3: Explain What the PPI Audit Can and Cannot Establish
    lines += ['## PPI implementation and interpretation', '',
              '- Shared rectified risk: mean_L[CE(Y) − λ CE(qL)] + λ mean_U[CE(qU)], with normalized design weights under MAR. Signed correction targets are never clipped.',
              '- qL is out-of-fold; each visible label is excluded from its own Teacher fit. Model selection nests this inside visible-label CV. Both Students reuse identical Teacher predictions and CV folds.',
              '- LR uses the analytic gradient and L2 penalty. XGBoost uses the same risk gradient with a diagonal softmax Hessian upper bound, fixed tree settings, fixed rounds and bounded leaf updates. Tree training is an approximation, not an exact LR optimizer.',
              '- At λ=0, PPI exactly reuses the same-architecture Supervised model. At SSL weight=0 it does the same. Equal scores in those cases are intentional.',
              '- Teacher OOF / validation metrics, per-class F1, prediction disagreement, probability changes, all candidate CV scores and optimization details remain in experiments.sqlite. A positive λ changing predictions without improving held-out scores is not itself an implementation error.',
              '- PPI selected uses training CV Macro F1; it is not variance-optimal PPI++ tuning. PPI does not guarantee an accuracy or Macro F1 gain, especially with a weak Teacher, rare classes or MNAR bias.', '',
              'XGBoost derivative implementation follows the [official custom multiclass objective example](https://xgboost.readthedocs.io/en/stable/python/examples/custom_softmax.html).', '']
    failed = cases.loc[cases.status != 'complete']
    if not failed.empty:
        lines += ['## Failed cases', '']+[f'- {x.mechanism}/{x.budget}/{x.seed}: {x.error}' for x in failed.itertuples()]
    (RESULTS_DIR/'summary.md').write_text('\n'.join(lines)+'\n')
    print('Saved: 2 Student figures, summary.md, experiments.sqlite', flush=True)
