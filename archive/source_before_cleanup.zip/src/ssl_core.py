# Step 1: Share One Weighted Multiclass LR Objective Across All Students

import numpy as np
from catboost import CatBoostClassifier
from scipy.optimize import minimize
from scipy.sparse import csr_matrix, hstack
from scipy.special import logsumexp, softmax
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, log_loss
from sklearn.model_selection import KFold, StratifiedKFold

from config import DEFAULT
from model_utils import CLASSES, CATEGORICAL_FEATURES, create_preprocessor, prepare_catboost_features

K = len(CLASSES)


class NonEstimableCandidate(ValueError):
    pass


def normalized(weights):
    weights = np.asarray(weights, dtype=float)
    if not len(weights):
        return weights
    if not np.all(np.isfinite(weights) & (weights > 0)):
        raise ValueError('Risk weights must be finite and positive.')
    return weights / weights.mean()


def stratified_folds(y, seed, config=DEFAULT):
    minimum = int(np.bincount(y, minlength=K).min())
    if minimum < 2:
        return []
    return list(StratifiedKFold(min(config.cv_folds, minimum), shuffle=True, random_state=seed).split(np.zeros(len(y)), y))


def objective(parameters, XL, targetL, XU, targetU, penalty):
    weights = parameters.reshape(XL.shape[1], targetL.shape[1])
    loss, gradient = 0., np.zeros_like(weights)
    for X, target in [(XL, targetL), (XU, targetU)]:
        if not np.any(target):
            continue
        logits = X @ weights
        log_p = logits - logsumexp(logits, axis=1, keepdims=True)
        loss -= np.sum(target * log_p) / len(target)
        residual = np.exp(log_p) * target.sum(axis=1, keepdims=True) - target
        gradient += np.asarray(X.T @ residual) / len(target)
    loss += .5 * penalty * np.sum(weights[:-1]**2)
    gradient[:-1] += penalty * weights[:-1]
    return float(loss), gradient.ravel()


# Step 2: Support Confidence Filtering, MAR Weighting and Missing Classes

def fit_student(XL, y, XU, qL, qU, mode='supervised', strength=0., *,
                wl=None, wu=None, initial=None, weight=0., threshold=0., config=DEFAULT):
    wl = normalized(np.ones(len(y)) if wl is None else wl)
    wu = normalized(np.ones(len(qU)) if wu is None else wu)
    Y = np.eye(K)[y]
    targetL, targetU = wl[:, None]*Y, np.zeros_like(qU)
    diagnostics = {'weight': None, 'effective_weight': None, 'threshold': None, 'accepted': None, 'used': None}
    if mode in ['hard', 'soft']:
        if not 0 <= weight <= 1 or not 0 <= threshold <= 1:
            raise ValueError('SSL weight/threshold must be in [0,1].')
        accepted = qU.max(axis=1) >= threshold
        count = int(accepted.sum())
        effective = weight if count else 0.
        XU, qU, wu = XU[accepted], qU[accepted], normalized(wu[accepted])
        pseudo = np.eye(K)[qU.argmax(axis=1)] if mode == 'hard' else qU
        targetL, targetU = (1-effective)*wl[:, None]*Y, effective*wu[:, None]*pseudo
        diagnostics.update(weight=weight, effective_weight=effective, threshold=threshold,
                           accepted=count, used=count if effective else 0)
    elif mode == 'ppi':
        if not 0 <= strength <= 1:
            raise ValueError('PPI lambda must be in [0,1].')
        targetL, targetU = wl[:, None]*(Y-strength*qL), strength*wu[:, None]*qU
    elif mode != 'supervised':
        raise ValueError('Unknown Student risk.')
    active = np.any(targetL != 0, axis=0) | np.any(targetU != 0, axis=0)
    mass = targetL.mean(axis=0) + (targetU.mean(axis=0) if len(targetU) else 0)
    if (mass[active] <= 0).any():
        raise NonEstimableCandidate('Nonpositive corrected class mass.')
    if config.student_model == 'XGBoost':
        from tree_student import fit_tree
        model = fit_tree(XL, targetL, XU, targetU, active, config)
        diagnostics.update(iterations=config.tree_iterations, **model.diagnostics)
        return model, diagnostics
    start = np.zeros((XL.shape[1], active.sum())) if initial is None else initial[:, active]
    result = minimize(objective, start.ravel(),
                      args=(XL, targetL[:, active], XU, targetU[:, active], 1/(len(y)*config.student_C)),
                      method='L-BFGS-B', jac=True,
                      options={'maxiter': 5000, 'ftol': 1e-10, 'gtol': 1e-6, 'maxls': 100})
    if not result.success or not np.isfinite(result.fun):
        raise RuntimeError(f'Student optimizer failed: {result.message}')
    weights = np.zeros((XL.shape[1], K))
    weights[-1, ~active] = -1000.  # Absent classes receive zero probability, not invented labels.
    weights[:, active] = result.x.reshape(XL.shape[1], active.sum())
    diagnostics.update(iterations=int(result.nit), gradient=float(abs(result.jac).max()))
    return weights, diagnostics


# Step 3: Fit All Preprocessing on the Current Labeled Fold

def prepare_design(X, U, E):
    preprocessor = create_preprocessor().fit(X)
    def transform(table):
        if table.empty:
            return csr_matrix((0, len(preprocessor.get_feature_names_out())+1))
        return hstack([csr_matrix(preprocessor.transform(table)), np.ones((len(table), 1))], format='csr')
    return tuple(transform(table) for table in [X, U, E])


# Step 4: Cross-Fit Teachers with Explicit Four-Class Probability Alignment

def crossfit_teacher(X, y, U, E=None, *, wl=None, seed=42, config=DEFAULT):
    wl = normalized(np.ones(len(y)) if wl is None else wl)
    tables = [prepare_catboost_features(t) if t is not None else None for t in [X, U, E]]
    X, U, E = tables
    folds = stratified_folds(y, seed, config)
    policy = 'stratified'
    if not folds:
        folds = list(KFold(min(config.cv_folds, len(y)), shuffle=True, random_state=seed).split(X))
        policy = 'kfold_class_alignment'
    qL, qU = np.zeros((len(y), K)), np.zeros((len(U), K))
    qE = None if E is None else np.zeros((len(E), K))
    def predict(model, table, classes):
        probability = np.zeros((len(table), K))
        if table.empty:
            return probability
        if model is None:
            probability[:, classes[0]] = 1.
        else:
            probability[:, classes] = model.predict_proba(table)
        return probability
    for fit_ids, held_ids in folds:
        classes = np.unique(y[fit_ids])
        teacher = None
        if len(classes) > 1:
            teacher = CatBoostClassifier(iterations=config.teacher_iterations, depth=6, learning_rate=.05,
                                         loss_function='MultiClass', cat_features=tuple(CATEGORICAL_FEATURES),
                                         random_seed=seed, thread_count=1, verbose=False, allow_writing_files=False)
            teacher.fit(X.iloc[fit_ids], y[fit_ids], sample_weight=normalized(wl[fit_ids]))
            classes = teacher.classes_.astype(int)
        qL[held_ids] = predict(teacher, X.iloc[held_ids], classes)
        fraction = len(held_ids)/len(y)
        qU += fraction*predict(teacher, U, classes)
        if E is not None:
            qE += fraction*predict(teacher, E, classes)
    return qL, qU, qE, policy


# Step 5: Evaluate All Four Classes on the Same Validation Set

def macro_f1(y, prediction, sample_weight=None):
    return f1_score(y, prediction, labels=np.arange(K), average='macro', zero_division=0, sample_weight=sample_weight)


def score(probability, y, baseline=None):
    prediction = probability.argmax(axis=1)
    result = {'accuracy': accuracy_score(y, prediction), 'macro_f1': macro_f1(y, prediction),
              'balanced_accuracy': balanced_accuracy_score(y, prediction),
              'log_loss': log_loss(y, probability, labels=np.arange(K)),
              'class_f1': f1_score(y, prediction, labels=np.arange(K), average=None, zero_division=0).tolist()}
    result['disagreement'] = 0. if baseline is None else float(np.mean(prediction != baseline.argmax(axis=1)))
    return result


def probabilities(X, weights):
    if hasattr(weights, 'predict_proba'):
        return weights.predict_proba(X)
    return softmax(X @ weights, axis=1)
