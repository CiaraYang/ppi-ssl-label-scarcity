# Step 1: Run One Matched SSL/PPI Case Using the Shared Engine

from pipeline import main

if __name__ == '__main__':
    main(single=True)
