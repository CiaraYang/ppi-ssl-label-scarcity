# Step 1: Run an Optional Training-Only LR Sensitivity Check

import argparse
from joblib import parallel_config
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import make_scorer
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from threadpoolctl import threadpool_limits

from masking import generate_mask
from model_utils import create_preprocessor, load_case
from pipeline import prepare_split
from ssl_core import macro_f1, stratified_folds
from storage import connect, dumps, initialize


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--labels', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    prepare_split()
    data = load_case(generate_mask(args.labels, args.seed, 'MCAR'))
    folds = stratified_folds(data.y, args.seed)
    if not folds:
        raise ValueError('Not enough visible labels per class for CV; increase --labels.')
    model = Pipeline([('preprocessor', create_preprocessor()),
                      ('model', LogisticRegression(max_iter=5000, random_state=args.seed))])
    search = GridSearchCV(model, {'model__C': [.01, .1, 1., 10., 100.],
                                 'model__class_weight': [None, 'balanced']},
                          scoring=make_scorer(macro_f1), cv=folds, n_jobs=2, pre_dispatch=2,
                          error_score='raise', refit=False)
    with parallel_config(backend='loky', inner_max_num_threads=1), threadpool_limits(limits=1):
        search.fit(data.X, data.y)
    result = {'budget': args.labels, 'seed': args.seed, 'best_parameters': search.best_params_,
              'cv_mean_macro_f1': search.best_score_,
              'candidates': [{'parameters': p, 'mean_macro_f1': float(mean), 'std_macro_f1': float(std)}
                             for p, mean, std in zip(search.cv_results_['params'], search.cv_results_['mean_test_score'], search.cv_results_['std_test_score'])],
              'scope': 'optional sensitivity only; does not change frozen Config or use validation labels'}
    with connect() as db:
        initialize(db)
        db.execute('INSERT OR REPLACE INTO sensitivity VALUES(?,?)', (f'MCAR_{args.labels}_{args.seed}', dumps(result)))
        db.commit()
    print(f'CV Macro F1={search.best_score_:.4f} | {search.best_params_}')


if __name__ == '__main__':
    main()
