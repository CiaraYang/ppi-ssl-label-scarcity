# Step 1: Use One Entry Point for the Whole Reproducible Study

import argparse
import importlib.util
import json
from itertools import product
from pathlib import Path

from joblib import Parallel, delayed, parallel_config

from config import DEFAULT
from experiment import fully_labeled_reference, run_case
from model_utils import DB_PATH, RESULTS_DIR, SPLIT_PATH, training_features
from storage import connect, dumps, get_metadata, initialize, save_case, set_metadata


def prepare_split():
    if not SPLIT_PATH.exists():
        path = Path(__file__).with_name('01_prepare_data.py')
        spec = importlib.util.spec_from_file_location('prepare_data', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.main()


def evaluate(key):
    mechanism, budget, seed = key
    try:
        rows, audit = run_case(budget, mechanism, seed)
        return key, rows, audit, None
    except Exception as error:
        return key, [], {}, f'{type(error).__name__}: {error}'


# Step 2: Resume Matching Cases and Commit Only in the Parent Process

def run_study(budgets, mechanisms, seeds, workers=2, fresh=False, retry_failed=False, plot=True):
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    prepare_split()
    if fresh:
        DB_PATH.unlink(missing_ok=True)
        for name in ['learning_curves.png', 'learning_curves_lr.png', 'learning_curves_xgboost.png', 'summary.md']:
            (RESULTS_DIR/name).unlink(missing_ok=True)
    with connect() as db:
        initialize(db)
        if db.execute('SELECT COUNT(*) FROM reference').fetchone()[0] == 0:
            reference = fully_labeled_reference()
            db.execute('INSERT INTO reference VALUES(1,?)', (dumps(reference),))
            db.commit()
        reference = json.loads(db.execute('SELECT value FROM reference').fetchone()[0])
        for name, result in reference.items():
            print(f"Fully labeled {name}: Accuracy={result['accuracy']:.4f}, Macro F1={result['macro_f1']:.4f}", flush=True)
        grid = {'budgets': list(budgets), 'mechanisms': list(mechanisms), 'seeds': list(seeds)}
        set_metadata(db, 'grid', grid)
        set_metadata(db, 'status', 'running')
        tasks = list(product(mechanisms, budgets, seeds))
        existing = {tuple(row[:3]): row[3] for row in db.execute('SELECT mechanism,budget,seed,status FROM cases')}
        pending = [key for key in tasks if key not in existing or (retry_failed and existing[key] == 'failed')]
        completed = len(tasks)-len(pending)
        print(f'{len(tasks)} cases | {completed} cached | {workers} CPU workers', flush=True)
        try:
            with parallel_config(backend='loky', inner_max_num_threads=1):
                results = Parallel(n_jobs=workers, return_as='generator_unordered')(
                    delayed(evaluate)(key) for key in pending)
                for key, rows, audit, error in results:
                    save_case(db, key, rows, audit, error)
                    completed += 1
                    if error:
                        print(f'FAILED {key}: {error}', flush=True)
                    elif completed % 10 == 0 or completed == len(tasks):
                        print(f'[{completed}/{len(tasks)}] saved', flush=True)
        except BaseException:
            set_metadata(db, 'status', 'interrupted')
            raise
        failed = [key for key in tasks if db.execute('SELECT status FROM cases WHERE mechanism=? AND budget=? AND seed=?', key).fetchone()[0] != 'complete']
        set_metadata(db, 'failed_cases', failed)
        set_metadata(db, 'status', 'complete_with_failures' if failed else 'complete')
    if plot:
        from visualization import make_outputs
        make_outputs()
    if failed:
        raise RuntimeError(f'{len(failed)} cases failed; see the database and use --retry-failed after diagnosis.')


# Step 3: Keep Optional Single-Case Commands Consistent with the Main Runner

def main(single=False):
    parser = argparse.ArgumentParser()
    parser.add_argument('--budgets', type=int, nargs='+', default=[200] if single else list(DEFAULT.budgets))
    parser.add_argument('--mechanisms', choices=DEFAULT.mechanisms, nargs='+', default=['MCAR'] if single else list(DEFAULT.mechanisms))
    parser.add_argument('--seeds', type=int, nargs='+', default=[42] if single else list(DEFAULT.seeds))
    parser.add_argument('--workers', type=int, choices=[1, 2], default=2)
    parser.add_argument('--fresh', action='store_true')
    parser.add_argument('--retry-failed', action='store_true')
    args = parser.parse_args()
    for values in [args.budgets, args.mechanisms, args.seeds]:
        if len(set(values)) != len(values):
            parser.error('Duplicate budgets, mechanisms or seeds are not allowed.')
    prepare_split()
    maximum = len(training_features())-2
    if any(budget < 2 or budget > maximum for budget in args.budgets):
        parser.error(f'Budgets must be between 2 and n_train-2 ({maximum}).')
    run_study(args.budgets, args.mechanisms, args.seeds, args.workers, args.fresh, args.retry_failed)
