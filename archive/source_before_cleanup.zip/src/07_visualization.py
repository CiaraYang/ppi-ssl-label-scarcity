# Step 1: Regenerate the Figure and Summary from the Existing Database

from visualization import make_outputs

if __name__ == '__main__':
    make_outputs()
