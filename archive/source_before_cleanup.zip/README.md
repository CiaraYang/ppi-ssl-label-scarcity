# CS 680 — Classification with Missing Labels

This ML project asks whether unlabeled training data improve classification when only **50, 100, 200, 500 or 1,000 labels** are visible, and whether a PPI-inspired rectified loss reduces negative transfer from imperfect pseudo-labels.

## Run

Use Python 3.13. For a new environment:

```bash
python3.13 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

From the project directory:

```bash
.venv/bin/python src/run_project.py --workers 2
```

This runs **MCAR / MAR / MNAR × 5 budgets × seeds 42–46 = 75 cases**, and automatically generates two Student figures and one summary. A matching interrupted run resumes from the same SQLite database. Native models use one thread each; at most two workers run.

```bash
# Replace previous experiment results after changing code/configuration.
.venv/bin/python src/run_project.py --fresh --workers 2

# A small development run; its requested grid is recorded explicitly.
.venv/bin/python src/run_project.py --budgets 50 100 --mechanisms MCAR MAR --seeds 42 --workers 2

# Redraw existing completed results without retraining.
.venv/bin/python src/07_visualization.py

# Run correctness checks.
.venv/bin/python -m unittest discover -s tests -v
```

If any case fails, its error remains visible in the database and summary. Diagnose it before using `--retry-failed`. Code/config/data mismatches require `--fresh`; cached cases from a different protocol cannot silently enter the comparison.

## Minimal files

The raw **cp1252** dataset remains at `data/Aircraft_Incident_Dataset_Kaggle.csv`. Existing independent train / validation / test assignments are preserved; exact-record duplicates have one modeling representative. Natural missing targets and the separate aircraft-missing category remain outside this controlled four-class population.

`results/` contains only:

- `split_manifest.csv` and `split_metadata.json`: fixed input split, not per-case experiment output;
- `experiments.sqlite`: all method metrics, per-class F1, CV candidates, mask diagnostics, settings, errors, source/data hashes and resume state;
- `learning_curves_lr.png` and `learning_curves_xgboost.png`: one figure per Student architecture, three training methods plus its own fully labeled reference;
- `summary.md`: readable results, valid-seed counts and small-sample fallback cases.

Masks and pseudo-labels stay in memory. No per-case CSVs or model checkpoints are saved. Old generated result folders have been deleted. One source-only backup remains at `archive/source_before_fixed_budgets.zip`.

## Models and fair comparisons

Two Student architectures are compared **in separate figures**:

- **LR:** linear multiclass Logistic Regression with `C=1`.
- **XGBoost:** 100 rounds, depth 3, learning rate 0.05, L2 leaf penalty 5, minimum child weight 1, maximum leaf update 1. No row/column subsampling. These settings are fixed before the new run and identical across training methods.

Both use the same seven original features, row-wise Aircraft_Age calculation, fold-local median imputation, numeric standardization and categorical one-hot encoding. Preprocessing is fitted only on the current visible training fold. Across architectures, masks, labeled counts, CV folds and the Teacher predictions are identical. Within an architecture, only the training objective changes.

The **CatBoost Teacher** uses 500 iterations, depth 6 and learning rate 0.05. Each labeled row receives an OOF prediction from a Teacher that excluded its label. Probability columns are aligned to the four known classes. The Teacher is an auxiliary predictor, so it no longer appears as a competing Student curve; its scores remain in the database.

Each figure has exactly four lines:

| Line | Rule |
|---|---|
| Supervised | Fit this Student using only visible labels; apply IPW under MAR |
| SSL soft | Fit the same Student with true labels and confidence-filtered Teacher probability targets |
| PPI selected | Fit the same Student with signed rectified risk; select lambda by visible-label CV |
| Fully labeled LR / XGBoost | The same architecture/settings using all 22,586 training labels; black dashed reference |

SSL hard, a separate fixed-lambda PPI curve, Teacher and the unweighted MAR comparator have been removed from the main experiment. This reduces visual clutter without using validation scores to choose which methods look favorable. Lambda=1 remains a candidate in training CV, with all candidate scores retained.

SSL weights are `[0, 0.1, 0.5]`, confidence threshold is fixed at `0.8`, and PPI lambdas are `[0, 0.25, 0.5, 0.75, 1]`. This smaller predefined SSL grid limits runtime; the same grid applies to both Students. Selection uses the same visible-label Stratified CV folds, with nested cross-fitting of the Teacher. It never uses validation/test or hidden targets. Native models use one CPU thread each, with at most two parallel cases.

The data risks are:

```text
Supervised: mean_L[a * CE(Y)]
SSL soft:   (1-w)*mean_L[a * CE(Y)] + w*weighted_mean_accepted_U[CE(qU)]
PPI:        mean_L[a * (CE(Y) - lambda*CE(qL))] + lambda*mean_U[b * CE(qU)]
```

LR adds the same `||W||²/(2*n_labeled*C)` penalty to every method. XGBoost scales every data risk by `n_labeled` and uses the same tree regularization, rounds, depth and update bound across methods. It implements a **custom signed multiclass objective**, not ordinary hard pseudo-label fitting: gradient is `p*sum(target)-target`; the diagonal softmax Hessian upper bound is `2*row_mass*p*(1-p)` with a numerical floor. Signed target entries are never clipped. The implementation follows the [official XGBoost example](https://xgboost.readthedocs.io/en/stable/python/examples/custom_softmax.html). Tree fitting is approximate and does not inherit exact LR optimization guarantees.

SSL weight is a mixing coefficient between normalized pools; unlabeled sample count does not automatically overpower true labels. Raw Teacher confidence is not calibrated correctness probability. At SSL weight=0 or an empty final accepted pool, reuse the same-architecture supervised fit exactly. At PPI lambda=0, reuse that same baseline exactly.

The full-label reference is computed in isolation. Its predictions, parameters and fitted preprocessing never enter limited-budget cases. It is a resource-rich reference, not a guaranteed upper bound.

## Missingness mechanisms

All mechanisms reveal exactly the requested number of training labels, with budgets nested within a seed. Masks are deterministic and never resampled to obtain favorable class balance.

- **MCAR:** uniform sampling without replacement. Every record has inclusion probability `n_labeled/n_train`.
- **MAR:** split records by observed `Incident_Year >= 2023`. Recent records receive a lower labeling allocation (configured selection ratio 0.25). Within each stratum, select a fixed number uniformly. The **exact inclusion probability is quota / stratum size**; these are not arbitrary `numpy.choice` weights. Both strata retain positive observation and non-observation probabilities.
- **MNAR:** the simulator gives `destroyed` outcomes lower labeling allocation. Only the simulator reads these outcomes. Learners receive visible labels and no oracle propensity information. This is an unadjusted **MNAR stress test**: PPI correction is not claimed to eliminate MNAR selection bias.

For MAR, the Teacher and all main SSL/PPI Students use self-normalized design weights `1/pi` for labeled samples and `1/(1-pi)` for unlabeled risks. CV holdout scores use design weighting, with class-specific fold fractions accounted for. `PPI lambda=0` corresponds to the plotted **Supervised** baseline, which uses IPW under MAR and ordinary weights under MCAR/MNAR. The `delta_f1` reference is stored explicitly per case. Normalization improves numerical stability; no exact finite-sample unbiasedness or PPI++ inference guarantee is asserted.

## Very small labeled sets

At 50 labels, a class can have one or zero examples. This is a real property of the mask, not an exception to hide.

- Use up to three Stratified CV folds if all four classes have at least two examples.
- Otherwise, skip parameter selection and apply the predefined **SSL weight=0 / PPI selected lambda=0** fallback. The Teacher is still evaluated for diagnostics; lambda=1 candidate scores are retained when CV is possible.
- Teacher OOF uses ordinary shuffled KFold if four-class stratification is impossible, with explicit class alignment.
- Student fits only supported classes and assigns zero probability to unsupported classes; validation Macro F1 always averages all four classes.
- Nonpositive corrected class mass makes a PPI candidate non-estimable. It is recorded, not clipped or silently presented as a successful fit. CV requires every fold to be valid; final selected PPI can back off to a smaller feasible lambda using training quantities only.

Every case stores class counts, fold count and fallback reason. Plot bands are between-mask **SD**, not confidence intervals. The summary reports selected lambda=0 counts and paired PPI-minus-Supervised differences.

## Evaluation and project structure

All curves use the same **4,840-row validation/development set**. The **4,841-row test set has no performance evaluation**. Previous validation exploration makes it development data; final test evaluation should follow a frozen method decision. This is a classification project, not parameter confidence-interval estimation. `PPI selected` is CV-tuned predictive rectification, not variance-optimal PPI++ power tuning.

```text
src/config.py          one frozen experiment configuration
src/model_utils.py     data cleaning, fixed split, visible-label loader, preprocessing
src/masking.py         exact-count MCAR / MAR / MNAR simulators
src/ssl_core.py        weighted risk, LR optimizer and cross-fitted Teacher
src/tree_student.py    matched XGBoost custom signed-risk optimizer
src/selection.py       training-only CV and small-sample rules
src/experiment.py      one complete matched case and isolated full-label reference
src/storage.py         one transactional SQLite database
src/pipeline.py        bounded parallel execution and safe resume
src/visualization.py   two architecture figures and one summary
src/run_project.py     recommended entry point
```

Numbered scripts are lightweight entry points: 01 rebuilds the fixed split; 02 inspects a mask without saving it; 03 computes the full-label reference; 04/05 run one matched case; 06 runs the full study; 07 redraws it. **Do not run 04 and 05 successively expecting different implementations**—both use the shared engine. The optional 03.1 script performs an LR-only training-CV sensitivity check and saves it into the same database; it never silently changes the frozen experiment configuration. The main XGBoost settings are fixed; this optional LR sensitivity does not select a winning architecture from validation scores.

The EDA notebook is read-only and writes no experiment results. Dependency versions are pinned in `requirements.txt`.

## PPI diagnostic checks

The test suite checks finite-difference gradients for weighted LR rectification and signed tree targets, the tree Hessian bound, supervised equivalence to sklearn LR / native XGBoost, exact zero-lambda/zero-weight baseline behavior, positive-lambda tree prediction changes, hidden/test target isolation and nested Teacher exclusion. The database stores selected lambda, candidate scores, prediction disagreement, mean absolute probability changes and optimizer diagnostics (including the tree empirical risk before/after fitting).

Passing these checks establishes specific implementation properties; it cannot guarantee PPI improves held-out Accuracy or Macro F1. A weak Teacher, very small rare-class counts, CV selection noise, and unadjusted MNAR bias can all limit gains. `PPI selected` is predictive rectification, **not variance-optimal PPI++ inference**. All curves use the same development set, not independent datasets.
